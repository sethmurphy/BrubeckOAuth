#!/usr/bin/env python

"""The Brubeck oAuth module."""

version = "0.1.0"
version_info = (0, 1, 0)
__all__ = [ 'base',
            'handlers',
            'queries',
            'settings']