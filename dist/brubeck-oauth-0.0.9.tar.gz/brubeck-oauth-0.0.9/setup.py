#!/usr/bin/env python
 
from distutils.core import setup
 
setup(name='brubeck-oauth',
      version='0.0.9',
      description='Brubeck OAuth module',
      author='Seth Murphy',
      author_email='seth@brooklyncode.com',
      url='http://github.com/sethmurphy/BrubeckOAuth',
      packages=['brubeckoauth'])
